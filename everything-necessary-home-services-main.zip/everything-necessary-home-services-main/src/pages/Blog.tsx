
import { useState } from 'react';
import { cn } from '@/lib/utils';
import { Filter } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ScrollToTop from '@/components/ScrollToTop';

// Define our blog post type
interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  author: string;
  date: string;
  category: string;
  imageUrl: string;
  slug: string;
}

// Define the service categories
const categories = [
  "All",
  "Plumbing",
  "HVAC",
  "Electrical",
  "Home Repair",
  "Renovation",
  "Home Inspection"
];

// Sample blog posts data
const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: "10 Signs You Need to Replace Your Water Heater",
    excerpt: "Water heaters typically last 8-12 years. Here are the warning signs that it's time for a replacement before a catastrophic failure.",
    author: "Michael Reynolds",
    date: "June 15, 2023",
    category: "Plumbing",
    imageUrl: "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    slug: "signs-replace-water-heater"
  },
  {
    id: 2,
    title: "How to Prepare Your HVAC System for Summer",
    excerpt: "Regular maintenance can keep your AC running efficiently during the hottest months. Follow these expert tips to prepare your system.",
    author: "Sarah Johnson",
    date: "April 22, 2023",
    category: "HVAC",
    imageUrl: "https://images.unsplash.com/photo-1581275868691-8640b72c4760?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    slug: "prepare-hvac-for-summer"
  },
  {
    id: 3,
    title: "The Ultimate Guide to Childproofing Your Home's Electrical System",
    excerpt: "Learn essential safety measures to protect curious children from electrical hazards around your home.",
    author: "David Chen",
    date: "May 10, 2023",
    category: "Electrical",
    imageUrl: "https://images.unsplash.com/photo-1558882224-dda166733046?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    slug: "childproofing-electrical-system"
  },
  {
    id: 4,
    title: "5 DIY Fixes for Squeaky Floors",
    excerpt: "Annoying floor squeaks can be fixed without calling a professional. Try these proven methods to silence those creaky boards.",
    author: "Jessica Miller",
    date: "March 5, 2023",
    category: "Home Repair",
    imageUrl: "https://images.unsplash.com/photo-1581858726788-75bc0f6a952d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    slug: "diy-fixes-squeaky-floors"
  },
  {
    id: 5,
    title: "Planning a Kitchen Renovation: Timeline and Budgeting Tips",
    excerpt: "Kitchen renovations can be overwhelming. This comprehensive guide walks you through planning, budgeting, and execution phases.",
    author: "Robert Wilson",
    date: "February 18, 2023",
    category: "Renovation",
    imageUrl: "https://images.unsplash.com/photo-1556912167-f556f1f39fdf?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    slug: "kitchen-renovation-guide"
  },
  {
    id: 6,
    title: "What to Expect During a Professional Home Inspection",
    excerpt: "Whether you're buying or selling a home, understanding the inspection process is crucial. Here's what inspectors look for.",
    author: "Amanda Taylor",
    date: "January 30, 2023",
    category: "Home Inspection",
    imageUrl: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    slug: "professional-home-inspection-guide"
  },
];

const Blog = () => {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [showCategoryMenu, setShowCategoryMenu] = useState(false);
  
  const filteredPosts = selectedCategory === "All" 
    ? blogPosts 
    : blogPosts.filter(post => post.category === selectedCategory);

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      <main className="flex-grow pt-24 pb-16">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-blue-50 to-indigo-50 py-16">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-display font-bold text-gray-900 mb-4">
                Home Service Insights
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                Expert advice, tips, and guidance for maintaining and improving your home
              </p>
            </div>
          </div>
        </section>
        
        {/* Category Filter */}
        <section className="py-8 border-b border-gray-200">
          <div className="container mx-auto px-4 md:px-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold text-gray-800">Latest Articles</h2>
              
              {/* Mobile Filter */}
              <div className="relative md:hidden">
                <button 
                  onClick={() => setShowCategoryMenu(!showCategoryMenu)}
                  className="flex items-center gap-2 px-4 py-2 bg-white rounded-md border border-gray-300 shadow-sm"
                >
                  <Filter size={16} />
                  <span>Filter: {selectedCategory}</span>
                </button>
                
                {showCategoryMenu && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg z-20 border border-gray-200">
                    {categories.map(category => (
                      <button
                        key={category}
                        className={cn(
                          "block w-full text-left px-4 py-2 hover:bg-gray-100",
                          selectedCategory === category ? "text-blue-600 font-medium" : "text-gray-700"
                        )}
                        onClick={() => {
                          setSelectedCategory(category);
                          setShowCategoryMenu(false);
                        }}
                      >
                        {category}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              
              {/* Desktop Categories */}
              <div className="hidden md:flex space-x-4">
                {categories.map(category => (
                  <button
                    key={category}
                    className={cn(
                      "px-4 py-2 rounded-full transition-colors",
                      selectedCategory === category 
                        ? "bg-blue-600 text-white" 
                        : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                    )}
                    onClick={() => setSelectedCategory(category)}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </section>
        
        {/* Blog Posts Grid */}
        <section className="py-12">
          <div className="container mx-auto px-4 md:px-6">
            {filteredPosts.length === 0 ? (
              <div className="text-center py-16">
                <p className="text-xl text-gray-600">No articles found in this category. Check back soon!</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredPosts.map(post => (
                  <article key={post.id} className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300">
                    <a href={`/blog/${post.slug}`} className="block">
                      <img 
                        src={post.imageUrl} 
                        alt={post.title}
                        className="w-full h-48 object-cover"
                      />
                      <div className="p-6">
                        <div className="flex items-center mb-4">
                          <span className="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full font-medium">
                            {post.category}
                          </span>
                          <span className="mx-2 text-gray-400">•</span>
                          <span className="text-gray-500 text-sm">{post.date}</span>
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 mb-2 hover:text-blue-600 transition-colors">
                          {post.title}
                        </h3>
                        <p className="text-gray-600 mb-4">{post.excerpt}</p>
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-medium">
                            {post.author.split(' ').map(name => name[0]).join('')}
                          </div>
                          <span className="ml-2 text-sm text-gray-700">{post.author}</span>
                        </div>
                      </div>
                    </a>
                  </article>
                ))}
              </div>
            )}
          </div>
        </section>
        
        {/* Newsletter Section */}
        <section className="bg-blue-600 py-16 mt-12">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl font-bold text-white mb-4">
                Subscribe to Our Newsletter
              </h2>
              <p className="text-blue-100 mb-8">
                Get the latest home maintenance tips and advice delivered directly to your inbox.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
                <input
                  type="email"
                  placeholder="Your email address"
                  className="flex-grow px-4 py-3 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-300"
                />
                <button className="bg-white text-blue-600 font-medium px-6 py-3 rounded-md hover:bg-blue-50 transition-colors">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
      <ScrollToTop />
    </div>
  );
};

export default Blog;
