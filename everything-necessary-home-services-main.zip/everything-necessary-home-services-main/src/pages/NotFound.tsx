
import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Home } from "lucide-react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-blue-50 px-4">
      <div className="text-center max-w-md">
        <div className="text-blue-600 text-9xl font-bold mb-4">404</div>
        <h1 className="text-3xl md:text-4xl font-display font-bold mb-4">Page Not Found</h1>
        <p className="text-lg text-muted-foreground mb-8">
          We're sorry, the page you're looking for doesn't exist or has been moved.
        </p>
        <a 
          href="/" 
          className="inline-flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-medium px-6 py-3 rounded-md shadow-sm transition-all transform hover:translate-y-[-2px]"
        >
          <Home size={18} />
          Return to Home
        </a>
      </div>
    </div>
  );
};

export default NotFound;
