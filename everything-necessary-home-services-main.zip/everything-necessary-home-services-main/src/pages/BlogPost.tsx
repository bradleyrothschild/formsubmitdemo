
import { useParams, useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { ArrowLeft, Calendar, User, Tag, Facebook, Twitter, Linkedin } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ScrollToTop from '@/components/ScrollToTop';

// Define our blog post type
interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  content?: string;
  author: string;
  date: string;
  category: string;
  imageUrl: string;
  slug: string;
}

// Sample blog posts data with content
const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: "10 Signs You Need to Replace Your Water Heater",
    excerpt: "Water heaters typically last 8-12 years. Here are the warning signs that it's time for a replacement before a catastrophic failure.",
    content: `
      <p>Your water heater works hard behind the scenes, providing hot water for showers, dishes, laundry, and more. But like any appliance, it won't last forever. Here are 10 warning signs that indicate your water heater may need replacement:</p>
      
      <h3>1. Age</h3>
      <p>Most water heaters last 8-12 years. If yours is approaching or exceeding this age range, it's time to start shopping for a replacement, even if it's still functioning.</p>
      
      <h3>2. Rusty Water</h3>
      <p>If your hot water appears rusty or has a metallic smell or taste, your water heater tank might be corroding from the inside.</p>
      
      <h3>3. Noise and Rumbling</h3>
      <p>As water heaters age, sediment builds up on the tank bottom. When this sediment hardens, you'll often hear rumbling or banging noises as the heater works.</p>
      
      <h3>4. Water Around the Heater</h3>
      <p>Moisture or small pools of water around your water heater often indicate a leak or fracture in the tank. Once the tank starts leaking, it usually needs replacement.</p>
      
      <h3>5. Inconsistent Water Temperature</h3>
      <p>If your shower suddenly goes cold before you're finished, your water heater might be failing to heat consistently.</p>
      
      <h3>6. Reduced Hot Water Volume</h3>
      <p>If you're running out of hot water more quickly than before, sediment buildup might have reduced your tank's capacity.</p>
      
      <h3>7. Frequent Repairs</h3>
      <p>If you've needed several repairs in the past two years, replacement might be more cost-effective than continued repairs.</p>
      
      <h3>8. Higher Energy Bills</h3>
      <p>An inefficient water heater has to work harder, consuming more energy and increasing your utility bills.</p>
      
      <h3>9. Cracks in the Tank</h3>
      <p>Visible cracks in the tank body indicate serious structural problems that usually cannot be repaired.</p>
      
      <h3>10. Discolored or Rusty Connections</h3>
      <p>Rust on the water inlet or pressure relief valve often foretells tank failure.</p>
      
      <h3>What To Do Next</h3>
      <p>If you've noticed several of these warning signs, it's time to consult with a professional plumber. At Everything Necessary, our experienced technicians can assess your water heater's condition and recommend appropriate solutions. Sometimes, simple repairs can extend your unit's life. Other times, replacement is the more practical and economical choice.</p>
      
      <p>Modern water heaters are more energy-efficient than older models, potentially saving you money on utility bills. We can help you select the right size and type for your household needs.</p>
      
      <p>Don't wait for a catastrophic leak or complete breakdown! Contact us today for a water heater assessment.</p>
    `,
    author: "Michael Reynolds",
    date: "June 15, 2023",
    category: "Plumbing",
    imageUrl: "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    slug: "signs-replace-water-heater"
  },
  {
    id: 2,
    title: "How to Prepare Your HVAC System for Summer",
    excerpt: "Regular maintenance can keep your AC running efficiently during the hottest months. Follow these expert tips to prepare your system.",
    content: `
      <p>As summer approaches, ensuring your HVAC system is ready for the heat is crucial for comfort and efficiency. Here's how to prepare your system:</p>
      
      <h3>Replace Air Filters</h3>
      <p>Start with the simplest step: replacing dirty air filters. Clogged filters restrict airflow, making your system work harder and less efficiently. Ideally, change filters every 1-3 months, depending on usage and filter type.</p>
      
      <h3>Clean the Outdoor Unit</h3>
      <p>Your AC's outdoor condenser unit needs good airflow. Clear away debris, leaves, and vegetation within a 2-foot radius. Gently clean the exterior fins with a soft brush or vacuum, being careful not to bend them.</p>
      
      <h3>Check Thermostat Operation</h3>
      <p>Test your thermostat by setting it to "cool" and lowering the temperature. Listen for the system to activate within a minute or two. Consider upgrading to a programmable or smart thermostat for better efficiency.</p>
      
      <h3>Inspect Ductwork</h3>
      <p>Examine accessible ductwork for visible leaks, disconnections, or damage. Sealing leaky ducts can significantly improve system efficiency and comfort.</p>
      
      <h3>Clear Drainage</h3>
      <p>Locate your AC's condensate drain line and ensure it's clear. Pouring a cup of white vinegar through it can help prevent algae growth that might cause clogs.</p>
      
      <h3>Test System Operation</h3>
      <p>Run your system for 15-30 minutes, checking that air flowing from vents feels cool and that the system operates without unusual noises.</p>
      
      <h3>Professional Maintenance</h3>
      <p>While DIY maintenance is helpful, annual professional service is essential. A technician will:</p>
      <ul>
        <li>Check refrigerant levels and test for leaks</li>
        <li>Inspect electrical components and connections</li>
        <li>Clean coils and blower components</li>
        <li>Lubricate moving parts</li>
        <li>Calibrate thermostat operation</li>
        <li>Identify potential issues before they become major problems</li>
      </ul>
      
      <h3>Consider System Age</h3>
      <p>If your AC system is over 10 years old, evaluate its efficiency. Newer systems can be up to 40% more efficient, potentially justifying the investment for significant energy savings.</p>
      
      <h3>Optimize Airflow</h3>
      <p>Ensure all supply and return vents are unobstructed by furniture, drapes, or other items that might restrict airflow.</p>
      
      <h3>Ceiling Fans</h3>
      <p>Use ceiling fans to complement your AC. When running counterclockwise, they create a cooling breeze that can allow you to set your thermostat a few degrees higher without sacrificing comfort.</p>
      
      <p>By following these preparation steps, you'll ensure your HVAC system is ready to keep you cool efficiently all summer long. For professional maintenance or if you notice any issues during your inspection, contact our HVAC experts at Everything Necessary.</p>
    `,
    author: "Sarah Johnson",
    date: "April 22, 2023",
    category: "HVAC",
    imageUrl: "https://images.unsplash.com/photo-1581275868691-8640b72c4760?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    slug: "prepare-hvac-for-summer"
  },
  {
    id: 3,
    title: "The Ultimate Guide to Childproofing Your Home's Electrical System",
    excerpt: "Learn essential safety measures to protect curious children from electrical hazards around your home.",
    content: `
      <p>Keeping children safe from electrical hazards is a top priority for any family. Young children are naturally curious and may not understand the dangers of electricity. Here's how to childproof your home's electrical system effectively:</p>
      
      <h3>Cover Unused Outlets</h3>
      <p>The simplest step is to install outlet covers or plugs in all unused electrical outlets. Choose covers that are difficult for small fingers to remove but easy for adults to use. For frequently used outlets, consider sliding outlet covers that automatically close when plugs are removed.</p>
      
      <h3>Secure Cords and Cables</h3>
      <p>Loose cords present both electrical and tripping hazards:</p>
      <ul>
        <li>Use cord concealer kits to hide cords against walls</li>
        <li>Secure loose cords with cord clips or cord covers</li>
        <li>Keep cords for window blinds and curtains out of reach</li>
        <li>Never run cords under rugs where they can overheat</li>
      </ul>
      
      <h3>Power Strip Protection</h3>
      <p>Place power strips out of reach or use power strip covers. Consider models with individual outlet covers for added protection.</p>
      
      <h3>Install GFCI Outlets</h3>
      <p>Ground Fault Circuit Interrupter (GFCI) outlets automatically shut off power when they detect irregularities, preventing shocks. They're especially important in bathrooms, kitchens, garages, and outdoor areas.</p>
      
      <h3>Use Cord Shorteners</h3>
      <p>For essential items with long cords, use cord shorteners to prevent excess cord from becoming a hazard.</p>
      
      <h3>Tamper-Resistant Receptacles</h3>
      <p>Consider replacing standard outlets with tamper-resistant receptacles, which have built-in shutters that prevent objects from being inserted into the slots.</p>
      
      <h3>Secure Entertainment Centers</h3>
      <p>Entertainment centers and computer stations often have multiple cords and devices. Use cord organizers and consider furniture specially designed to hide cords.</p>
      
      <h3>Check for Warm Outlets or Switches</h3>
      <p>Regularly check for outlets or switches that feel warm to the touch, as this may indicate a hazardous wiring condition requiring professional attention.</p>
      
      <h3>Install Arc Fault Circuit Interrupters (AFCIs)</h3>
      <p>AFCIs detect dangerous electrical arcs and shut off power before a fire can start. Consider having an electrician install these, especially in bedrooms.</p>
      
      <h3>Create a "No-Go Zone"</h3>
      <p>Establish areas where electrical equipment is concentrated as off-limits to children. Use baby gates or furniture arrangements to block access.</p>
      
      <h3>Teach Age-Appropriate Safety</h3>
      <p>As children grow, teach them about electrical safety in ways they can understand:</p>
      <ul>
        <li>Never touch outlets or stick anything into them</li>
        <li>Stay away from electrical appliances when wet</li>
        <li>Never pull plugs by the cord</li>
        <li>Stay away from power lines outside</li>
      </ul>
      
      <h3>Regular Electrical Inspections</h3>
      <p>Have your home's electrical system professionally inspected every 5-10 years to identify potential hazards before they become dangerous.</p>
      
      <p>If you need help implementing any of these childproofing measures or want a professional assessment of your home's electrical safety, contact Everything Necessary. Our licensed electricians can help create a safer environment for your family.</p>
    `,
    author: "David Chen",
    date: "May 10, 2023",
    category: "Electrical",
    imageUrl: "https://images.unsplash.com/photo-1558882224-dda166733046?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    slug: "childproofing-electrical-system"
  },
  {
    id: 4,
    title: "5 DIY Fixes for Squeaky Floors",
    excerpt: "Annoying floor squeaks can be fixed without calling a professional. Try these proven methods to silence those creaky boards.",
    content: `
      <p>Few things are more annoying than a squeaky floor that wakes up sleeping family members or interrupts your peace and quiet. Fortunately, many floor squeaks can be remedied with straightforward DIY repairs:</p>
      
      <h3>1. Use Baby Powder for Quick Relief</h3>
      <p>For a simple first attempt, try sprinkling baby powder, talcum powder, or powdered graphite between the squeaky floorboards. The powder helps reduce friction between rubbing surfaces - often the cause of squeaks. Sweep the powder into the cracks with a soft brush, then walk on the area to work it into the crevices.</p>
      
      <h3>2. Drive Screws Through Carpeted Floors</h3>
      <p>For squeaky floors under carpet:</p>
      <ol>
        <li>Locate the floor joist beneath the squeak using a stud finder</li>
        <li>Use a screw designed for this purpose (like Squeeeeek-No-More) that allows you to drive a special scored screw through the carpet and subfloor into the joist</li>
        <li>Once secured, the screw breaks off below the carpet surface, leaving no visible trace</li>
      </ol>
      
      <h3>3. Reinforce From Below</h3>
      <p>If you have access to the underside of your squeaky floor (through a basement or crawlspace):</p>
      <ol>
        <li>Have someone walk on the floor above while you observe from below to pinpoint the exact squeak location</li>
        <li>Apply wood glue to a thin wood shim and gently tap it into any gap between the subfloor and the joist (don't force it)</li>
        <li>For wider gaps, glue and screw a 2x4 brace between joists, pressed firmly against the underside of the subfloor</li>
      </ol>
      
      <h3>4. Secure Loose Boards with Finish Screws</h3>
      <p>For squeaks in exposed hardwood floors:</p>
      <ol>
        <li>Locate the squeak and identify the loose board</li>
        <li>Pre-drill holes at a 45-degree angle through the board into the subfloor or joist</li>
        <li>Countersink trim-head screws just below the surface</li>
        <li>Fill the holes with wood putty that matches your floor color</li>
      </ol>
      
      <h3>5. Use Lubricating Oil for Tongue-and-Groove Floors</h3>
      <p>If the squeak is coming from the seam between boards:</p>
      <ol>
        <li>Clean the area thoroughly</li>
        <li>Apply a small amount of dry lubricant or WD-40 into the seam</li>
        <li>Wipe away any excess immediately to prevent floor damage</li>
        <li>Walk on the area to work in the lubricant</li>
      </ol>
      
      <h3>When to Call a Professional</h3>
      <p>Consider professional help if:</p>
      <ul>
        <li>Your attempts don't resolve the issue</li>
        <li>The squeaks are widespread throughout your home</li>
        <li>You notice sagging or uneven floors along with the squeaks</li>
        <li>You have an expensive or historic hardwood floor</li>
        <li>You're uncertain about the structural condition of your subfloor or joists</li>
      </ul>
      
      <p>At Everything Necessary, our flooring experts can quickly diagnose and fix persistent floor squeaks that resist DIY solutions. Contact us for a consultation if you need assistance with more complex floor repairs.</p>
    `,
    author: "Jessica Miller",
    date: "March 5, 2023",
    category: "Home Repair",
    imageUrl: "https://images.unsplash.com/photo-1581858726788-75bc0f6a952d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    slug: "diy-fixes-squeaky-floors"
  },
  {
    id: 5,
    title: "Planning a Kitchen Renovation: Timeline and Budgeting Tips",
    excerpt: "Kitchen renovations can be overwhelming. This comprehensive guide walks you through planning, budgeting, and execution phases.",
    content: `
      <p>A kitchen renovation is one of the most impactful home improvement projects you can undertake, but it can also be one of the most complex. This guide will help you navigate the planning, budgeting, and execution phases of your kitchen remodel.</p>
      
      <h3>Realistic Timeline</h3>
      <p>A full kitchen renovation typically takes 2-5 months from initial planning to completion:</p>
      
      <h4>Planning Phase (2-6 weeks)</h4>
      <ul>
        <li>Gather inspiration and determine your style preferences</li>
        <li>Set your budget and priorities</li>
        <li>Research and select a contractor</li>
        <li>Finalize design plans and materials</li>
        <li>Obtain necessary permits</li>
      </ul>
      
      <h4>Demolition Phase (3-7 days)</h4>
      <ul>
        <li>Remove existing cabinets, appliances, flooring, and possibly walls</li>
        <li>Address any discovered issues (mold, electrical, plumbing)</li>
      </ul>
      
      <h4>Construction Phase (3-8 weeks)</h4>
      <ul>
        <li>Rough-in electrical and plumbing work (1 week)</li>
        <li>Install new windows or doors if applicable (1-2 days)</li>
        <li>Wall repair, prep, and painting (3-5 days)</li>
        <li>Flooring installation (2-5 days)</li>
        <li>Cabinet installation (1-2 weeks)</li>
        <li>Countertop templating and installation (2 weeks)</li>
        <li>Backsplash installation (1-3 days)</li>
        <li>Appliance installation (1-2 days)</li>
        <li>Final plumbing and electrical fixtures (1-3 days)</li>
      </ul>
      
      <h4>Final Details (1 week)</h4>
      <ul>
        <li>Hardware installation</li>
        <li>Touch-ups and clean-up</li>
        <li>Final inspections</li>
      </ul>
      
      <h3>Budgeting Breakdown</h3>
      <p>For budgeting purposes, consider these typical percentages of your total budget:</p>
      <ul>
        <li>Cabinets and hardware: 30-35%</li>
        <li>Labor and installation: 20-25%</li>
        <li>Appliances: 15-20%</li>
        <li>Countertops: 10-15%</li>
        <li>Flooring: 5-10%</li>
        <li>Lighting fixtures: 5%</li>
        <li>Backsplash, paint, and miscellaneous: 5-10%</li>
        <li>Contingency fund: 10-20% (for unexpected issues)</li>
      </ul>
      
      <h3>Money-Saving Tips</h3>
      <p>To manage costs effectively:</p>
      <ul>
        <li>Consider cabinet refacing instead of full replacement</li>
        <li>Keep your existing layout to avoid moving plumbing and electrical</li>
        <li>Choose mid-range appliances with high-quality features</li>
        <li>Mix high-end and budget materials (e.g., splurge on countertops, save on backsplash)</li>
        <li>Tackle suitable DIY projects like painting or hardware installation</li>
        <li>Shop for floor models or slightly imperfect items at discount</li>
        <li>Plan your renovation during the off-season (typically winter)</li>
      </ul>
      
      <h3>Common Pitfalls to Avoid</h3>
      <ul>
        <li>Underestimating the total cost</li>
        <li>Forgetting about the "hidden" costs (permits, eating out during renovation)</li>
        <li>Changing plans mid-project</li>
        <li>Neglecting proper ventilation planning</li>
        <li>Sacrificing storage for aesthetics</li>
        <li>Choosing impractical materials (like porous stone for heavy-use areas)</li>
        <li>Ignoring the workflow triangle</li>
      </ul>
      
      <h3>Working With Professionals</h3>
      <p>A kitchen renovation typically involves multiple professionals:</p>
      <ul>
        <li>General contractor to oversee the project</li>
        <li>Kitchen designer for optimal layout and aesthetics</li>
        <li>Plumber for sink, dishwasher, and refrigerator water line</li>
        <li>Electrician for lighting and appliance wiring</li>
        <li>Carpenter for custom cabinetry or modifications</li>
        <li>Flooring specialist</li>
        <li>Countertop fabricator and installer</li>
        <li>Painter</li>
      </ul>
      
      <p>At Everything Necessary, we coordinate all these professionals for you, providing a single point of contact and ensuring seamless project management. Contact us to discuss your kitchen renovation dreams and let our experts create a detailed plan tailored to your needs and budget.</p>
    `,
    author: "Robert Wilson",
    date: "February 18, 2023",
    category: "Renovation",
    imageUrl: "https://images.unsplash.com/photo-1556912167-f556f1f39fdf?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    slug: "kitchen-renovation-guide"
  },
  {
    id: 6,
    title: "What to Expect During a Professional Home Inspection",
    excerpt: "Whether you're buying or selling a home, understanding the inspection process is crucial. Here's what inspectors look for.",
    content: `
      <p>A professional home inspection is a critical step in the home buying or selling process. Understanding what to expect can help you prepare and make the most of this valuable assessment.</p>
      
      <h3>Who Needs a Home Inspection?</h3>
      <ul>
        <li><strong>Buyers:</strong> To identify potential issues before purchasing</li>
        <li><strong>Sellers:</strong> To discover and address problems before listing</li>
        <li><strong>Homeowners:</strong> To assess condition before renovations or for maintenance planning</li>
      </ul>
      
      <h3>What Gets Inspected?</h3>
      <p>A thorough home inspection typically covers:</p>
      
      <h4>Exterior Components</h4>
      <ul>
        <li><strong>Roof:</strong> Shingles, flashing, chimneys, gutters, downspouts</li>
        <li><strong>Foundation:</strong> Visible cracks, drainage issues, signs of settling</li>
        <li><strong>Walls:</strong> Siding, trim, paint condition</li>
        <li><strong>Windows and Doors:</strong> Functionality, weather sealing, frames</li>
        <li><strong>Driveways and Walkways:</strong> Cracks, drainage, trip hazards</li>
        <li><strong>Decks and Porches:</strong> Structural integrity, railings, stairs</li>
        <li><strong>Grading:</strong> Property slope for proper drainage away from home</li>
      </ul>
      
      <h4>Interior Features</h4>
      <ul>
        <li><strong>Walls, Ceilings, Floors:</strong> Water damage, cracks, structural issues</li>
        <li><strong>Doors and Windows:</strong> Operation, locks, weatherstripping</li>
        <li><strong>Stairs and Railings:</strong> Safety and stability</li>
        <li><strong>Kitchen:</strong> Appliances, plumbing, electrical outlets, ventilation</li>
        <li><strong>Bathrooms:</strong> Toilets, showers, tubs, sinks, ventilation</li>
      </ul>
      
      <h4>Major Systems</h4>
      <ul>
        <li><strong>Electrical:</strong> Service panels, wiring, outlets, fixtures, GFCI protection</li>
        <li><strong>Plumbing:</strong> Supply lines, drainage, fixtures, water pressure, leaks</li>
        <li><strong>HVAC:</strong> Heating, cooling, filters, ductwork, thermostat operation</li>
        <li><strong>Water Heater:</strong> Age, condition, proper installation</li>
      </ul>
      
      <h4>Specialized Areas</h4>
      <ul>
        <li><strong>Attic:</strong> Insulation, ventilation, structural components, signs of leaks</li>
        <li><strong>Basement/Crawlspace:</strong> Moisture issues, insulation, structural elements</li>
        <li><strong>Garage:</strong> Doors, openers, fire separation, electrical</li>
      </ul>
      
      <h3>The Inspection Process</h3>
      <p>A typical inspection follows this sequence:</p>
      <ol>
        <li><strong>Scheduling:</strong> Typically takes 2-4 hours depending on home size</li>
        <li><strong>Attendance:</strong> Buyers should attend if possible; sellers usually leave</li>
        <li><strong>Exterior Examination:</strong> Inspector starts outside, examining foundation to roof</li>
        <li><strong>Interior Assessment:</strong> Room-by-room evaluation of all accessible areas</li>
        <li><strong>Systems Testing:</strong> Operation of appliances, HVAC, electrical, plumbing</li>
        <li><strong>Documentation:</strong> Photos and notes of findings</li>
        <li><strong>Report Delivery:</strong> Comprehensive report typically within 24-48 hours</li>
      </ol>
      
      <h3>After the Inspection</h3>
      <p>Once you receive the report:</p>
      <ol>
        <li>Review findings carefully, noting major versus minor issues</li>
        <li>Discuss concerns with your real estate agent</li>
        <li>For buyers: Decide if repairs should be negotiated with seller</li>
        <li>For sellers: Consider addressing significant issues before buyers request repairs</li>
        <li>For all: Develop a plan for addressing maintenance items</li>
      </ol>
      
      <h3>What's NOT Included</h3>
      <p>Standard home inspections typically don't include:</p>
      <ul>
        <li>Specialized tests (radon, mold, asbestos, lead paint)</li>
        <li>Inspection of inaccessible areas</li>
        <li>Code compliance certification</li>
        <li>Cosmetic issues assessment</li>
        <li>Appliance recall checks</li>
        <li>Estimates for repairs</li>
      </ul>
      
      <p>At Everything Necessary, our certified home inspectors provide thorough, unbiased assessments to give you confidence in your home-related decisions. We also offer specialized inspection services beyond the standard inspection. Contact us to schedule your professional home inspection today.</p>
    `,
    author: "Amanda Taylor",
    date: "January 30, 2023",
    category: "Home Inspection",
    imageUrl: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    slug: "professional-home-inspection-guide"
  },
];

const BlogPost = () => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const [post, setPost] = useState<BlogPost | null>(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    // Find the post that matches the slug
    const foundPost = blogPosts.find(post => post.slug === slug);
    
    if (foundPost) {
      setPost(foundPost);
      document.title = `${foundPost.title} | Everything Necessary`;
    } else {
      // Redirect to 404 if post not found
      navigate('/not-found', { replace: true });
    }
    
    setLoading(false);
  }, [slug, navigate]);
  
  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
    </div>;
  }
  
  if (!post) return null;
  
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      <main className="flex-grow pt-24 pb-16">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-blue-50 to-indigo-50 py-16">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-4xl mx-auto">
              <button 
                onClick={() => navigate('/blog')}
                className="flex items-center gap-2 mb-8 text-gray-600 hover:text-blue-600 transition-colors"
              >
                <ArrowLeft size={16} />
                <span>Back to all articles</span>
              </button>
              
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-display font-bold text-gray-900 mb-6">
                {post.title}
              </h1>
              
              <div className="flex flex-wrap items-center gap-4 text-gray-500 mb-8">
                <div className="flex items-center gap-2">
                  <Calendar size={18} />
                  <span>{post.date}</span>
                </div>
                <div className="flex items-center gap-2">
                  <User size={18} />
                  <span>{post.author}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Tag size={18} />
                  <span className="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full font-medium">
                    {post.category}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Featured Image */}
        <div className="container mx-auto px-4 md:px-6 -mt-8">
          <div className="max-w-4xl mx-auto">
            <img 
              src={post.imageUrl} 
              alt={post.title}
              className="w-full h-[400px] object-cover rounded-xl shadow-lg"
            />
          </div>
        </div>
        
        {/* Content */}
        <section className="py-12">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-3xl mx-auto">
              <div 
                className="prose prose-lg max-w-none"
                dangerouslySetInnerHTML={{ __html: post.content || '' }}
              >
              </div>
              
              <div className="border-t border-gray-200 mt-12 pt-8">
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="text-lg font-semibold text-gray-800 mb-2">About the Author</h4>
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white font-medium text-lg">
                        {post.author.split(' ').map(name => name[0]).join('')}
                      </div>
                      <div className="ml-4">
                        <p className="font-medium text-gray-800">{post.author}</p>
                        <p className="text-sm text-gray-500">Home Service Expert</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex space-x-4">
                    <a href="#" className="text-gray-500 hover:text-blue-500 transition-colors">
                      <Facebook size={20} />
                    </a>
                    <a href="#" className="text-gray-500 hover:text-blue-500 transition-colors">
                      <Twitter size={20} />
                    </a>
                    <a href="https://www.linkedin.com/company/everything-necessary-your-trusted-home-services-advisor/about/?viewAsMember=true" className="text-gray-500 hover:text-blue-500 transition-colors">
                      <Linkedin size={20} />
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="bg-blue-600 py-16">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl font-bold text-white mb-4">
                Need help with your home?
              </h2>
              <p className="text-blue-100 mb-8">
                Our team of experienced professionals is ready to help with all your home service needs.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="/#contact" className="bg-white text-blue-600 font-medium px-6 py-3 rounded-md hover:bg-blue-50 transition-colors">
                  Contact Us Today
                </a>
                <a href="/services" className="bg-transparent text-white border border-white font-medium px-6 py-3 rounded-md hover:bg-blue-700 transition-colors">
                  Explore Our Services
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
      <ScrollToTop />
    </div>
  );
};

export default BlogPost;
