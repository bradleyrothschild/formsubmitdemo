
import React, { useEffect } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { 
  Wrench, 
  Droplets, 
  Zap, 
  House, 
  Settings, 
  Shield, 
  RefreshCw, 
  Hammer, 
  Sparkles, 
  PaintBucket, 
  Workflow, 
  HeartPulse 
} from 'lucide-react';
import { Link } from "react-router-dom";

const Services = () => {
  useEffect(() => {
    // Initialize intersection observer for scroll animations
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        });
      },
      { threshold: 0.1 }
    );

    // Observe all elements with scroll-reveal class
    const scrollElements = document.querySelectorAll(".scroll-reveal");
    scrollElements.forEach((el) => observer.observe(el));

    return () => {
      scrollElements.forEach((el) => observer.unobserve(el));
    };
  }, []);

  const serviceCategories = [
    {
      title: "Repairs & Maintenance",
      icon: <Wrench className="w-6 h-6" />,
      description: "From plumbing leaks to electrical issues, HVAC repairs and more - we fix problems and keep your home systems running smoothly.",
      services: [
        "Plumbing Services: Leak repair, drain cleaning, toilet/faucet repair, water heater service, pipe repair",
        "Electrical Services: Repairs, wiring issues, outlet problems, lighting repair, electrical panel issues",
        "HVAC Services: Heating repair, AC repair, furnace/boiler maintenance, thermostat issues",
        "Appliance Repair: Refrigerator, oven, dishwasher, washer/dryer",
        "Handyman Services: General home repairs, minor carpentry, drywall patching, furniture assembly",
        "Roof Repair: Leak detection, minor roof repairs, shingle replacement, storm damage repair",
        "Gutter Repair: Gutter leaks, damage, sagging gutters",
        "Window Repair: Window leaks, broken panes, damaged frames, caulking/sealing",
        "Garage Door Repair: Garage door and opener repairs",
        "Chimney Repair: Chimney leaks, damage, brickwork repair"
      ]
    },
    {
      title: "Installations & Upgrades",
      icon: <RefreshCw className="w-6 h-6" />,
      description: "New HVAC systems, electrical installations, plumbing fixtures, smart home technology, and more to improve your home's functionality.",
      services: [
        "HVAC Installation: New furnace/boiler installation, AC installation, ductwork installation",
        "Electrical Installation: New wiring, new lighting fixtures, outlet installation, electrical panel upgrades",
        "Plumbing Installation: New toilet/faucet installation, water heater installation, new piping, water filtration systems",
        "Smart Home Installation: Smart thermostats, lighting systems, security systems, home automation",
        "Home Security Systems Installation: Alarm systems, cameras, doorbells",
        "Window Replacement: New window installation, energy-efficient window upgrades",
        "Door Installation: Exterior and interior door replacement/installation",
        "Fence Installation: New fence construction",
        "Deck & Patio Installation: New deck and patio construction",
        "Driveway & Walkway Paving: New driveway and walkway installation",
        "Sprinkler System Installation: New sprinkler system setup",
        "Fireplace Installation: New fireplace installation (gas, electric, wood)",
        "Garage Door Installation: New garage door and opener installation",
        "Water Filtration/Purification Systems: Water softeners, filters, reverse osmosis",
        "Septic System Installation: New septic system install",
        "Well System Installation: New well pump, well system install"
      ]
    },
    {
      title: "Home Cleaning",
      icon: <Sparkles className="w-6 h-6" />,
      description: "Professional cleaning services including house cleaning, carpet cleaning, window washing, and power washing.",
      services: [
        "House Cleaning: Regular cleaning, deep cleaning, move-in/move-out cleaning",
        "Carpet Cleaning: Regular and specialty carpet cleaning (stain removal)",
        "Upholstery Cleaning: Furniture and upholstery cleaning",
        "Window Cleaning: Interior and exterior window washing",
        "Gutter Cleaning: Regular gutter cleaning, debris removal",
        "Power Washing: Driveways, patios, decks, siding, fences",
        "Chimney Cleaning: Chimney sweeping"
      ]
    },
    {
      title: "Exterior & Property",
      icon: <PaintBucket className="w-6 h-6" />,
      description: "Complete property care with landscaping, tree services, fence repair, deck maintenance, and seasonal services.",
      services: [
        "Landscaping/Lawn Care: Lawn mowing, fertilization, weed control, aeration, gardening",
        "Tree Services: Tree trimming, tree removal, stump grinding",
        "Snow Removal: Plowing, shoveling, de-icing",
        "Fence Repair & Staining/Painting: Fence repairs, staining, painting",
        "Deck & Patio Repair & Refinishing: Deck/patio repairs, staining, sealing",
        "Driveway & Walkway Repair & Sealing: Driveway/walkway repairs, crack filling, sealing",
        "Pool Services: Pool cleaning, maintenance, repair, opening/closing",
        "Sprinkler System Services: Sprinkler repair, winterization, start-up",
        "Exterior Painting: Exterior house painting, trim painting, deck/fence painting",
        "Siding Repair & Cleaning: Siding repairs, siding cleaning"
      ]
    },
    {
      title: "Home Improvement",
      icon: <Hammer className="w-6 h-6" />,
      description: "Transform your space with kitchen and bathroom remodeling, flooring, painting, and custom carpentry solutions.",
      services: [
        "Kitchen Remodeling: Kitchen renovations, cabinet replacement, countertop install",
        "Bathroom Remodeling: Bathroom renovations, vanity replacement, tile work",
        "Basement Finishing/Remodeling: Basement renovations, finishing unfinished spaces",
        "Flooring Services: Flooring installation (carpet, hardwood, tile, laminate), refinishing",
        "Interior Painting: Interior wall painting, trim painting, ceiling painting",
        "Carpentry Services: Custom carpentry, built-ins, cabinet installation, trim work",
        "Tile & Grout Services: Tile installation, re-grouting as part of renovations",
        "Drywall Repair & Installation: Drywall work as part of renovations",
        "Attic Insulation & Ventilation Upgrades: Insulation upgrades, ventilation improvements"
      ]
    },
    {
      title: "Specialty Services",
      icon: <Workflow className="w-6 h-6" />,
      description: "Specialized solutions including junk removal, moving services, mold remediation, and seasonal installations.",
      services: [
        "Junk Removal & Hauling: Removing unwanted items, debris",
        "Moving Services: Local moving, packing, unpacking",
        "Home Inspection Services: Pre-purchase, pre-listing, maintenance inspections",
        "Mold Remediation: Mold inspection, removal, prevention",
        "Asbestos Abatement: Asbestos testing and removal",
        "Radon Mitigation: Radon testing and mitigation system installation",
        "Propane/Oil Delivery & Service: Fuel delivery, tank maintenance",
        "Natural Gas Line Services: Gas line installation, leak detection",
        "Holiday Lighting Installation & Removal: Seasonal service",
        "Well Water Services: Well pump repair/replacement, maintenance",
        "Septic System Services: Septic tank pumping, inspections",
        "Water Filtration/Purification: Complex water treatment systems",
        "Blind & Drapery Cleaning/Repair: Specialized cleaning service"
      ]
    },
    {
      title: "Emergency Services",
      icon: <HeartPulse className="w-6 h-6" />,
      description: "24/7 emergency assistance for plumbing, electrical, HVAC failures, water damage, and urgent tree removal.",
      services: [
        "Emergency Plumbing: Burst pipes, major leaks, sewer backups",
        "Emergency Electrical: Power outages, electrical fires, exposed wiring",
        "Emergency HVAC: Heating failure in winter, AC failure in summer",
        "Emergency Roofing: Major roof leaks, storm damage",
        "Water Damage Restoration: Flooding cleanup, water extraction",
        "Emergency Tree Removal: Dangerous tree situations"
      ]
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="pt-32 pb-16 bg-blue-50">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-4xl mx-auto text-center scroll-reveal">
              <h1 className="text-4xl md:text-5xl font-display font-bold mb-6 text-foreground">
                All Services Provided
              </h1>
              <p className="text-xl text-muted-foreground">
                Everything necessary for a happy home, all in one place. Browse our comprehensive list of services designed to keep your home running smoothly.
              </p>
            </div>
          </div>
        </section>

        {/* Services List Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4 md:px-6">
            {serviceCategories.map((category, index) => (
              <div key={index} className="mb-16 scroll-reveal">
                <div className="flex items-center mb-6">
                  <div className="bg-blue-100 p-4 rounded-full text-blue-600 mr-4">
                    {category.icon}
                  </div>
                  <h2 className="text-2xl md:text-3xl font-display font-bold">
                    {category.title}
                  </h2>
                </div>
                <p className="text-lg text-muted-foreground mb-6 pl-16">
                  {category.description}
                </p>
                <div className="bg-gray-50 p-6 rounded-xl">
                  <h3 className="text-xl font-semibold mb-4">Services include:</h3>
                  <ul className="grid md:grid-cols-2 gap-3">
                    {category.services.map((service, idx) => (
                      <li key={idx} className="flex items-start">
                        <div className="text-blue-600 mr-2 mt-1">•</div>
                        <span>{service}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-blue-100">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-3xl mx-auto text-center scroll-reveal">
              <h2 className="text-3xl font-display font-bold mb-6">
                Ready to get started?
              </h2>
              <p className="text-xl text-muted-foreground mb-8">
                Contact us today to schedule a service or get a free quote. We're ready to help with all your home service needs.
              </p>
              <Link
                to="/#contact"
                className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-8 rounded-md shadow-sm transition-colors"
              >
                Contact Us
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Services;
