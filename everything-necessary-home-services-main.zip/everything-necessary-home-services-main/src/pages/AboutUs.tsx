
import React, { useEffect } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Building, Star, Clock, MapPin } from "lucide-react";
import { Link } from "react-router-dom";

const AboutUs = () => {
  useEffect(() => {
    // Initialize intersection observer for scroll animations
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        });
      },
      { threshold: 0.1 }
    );

    // Observe all elements with scroll-reveal class
    const scrollElements = document.querySelectorAll(".scroll-reveal");
    scrollElements.forEach((el) => observer.observe(el));

    return () => {
      scrollElements.forEach((el) => observer.unobserve(el));
    };
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="pt-32 pb-16 bg-blue-50">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-4xl mx-auto text-center scroll-reveal">
              <h1 className="text-4xl md:text-5xl font-display font-bold mb-6 text-foreground">
                Your Trusted Partner for a Happy Home Across the Tri-State Area
              </h1>
              <p className="text-xl text-muted-foreground">
                At Everything Necessary, we believe that maintaining a
                comfortable and well-functioning home shouldn't be a source of
                stress. Your home is your sanctuary, and we're here to ensure it
                stays that way.
              </p>
            </div>
          </div>
        </section>

        {/* Introduction Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-4xl mx-auto scroll-reveal">
              <p className="text-lg text-muted-foreground mb-6">
                At Everything Necessary, we believe that maintaining a
                comfortable and well-functioning home shouldn't be a source of
                stress. Your home is your sanctuary, and we're here to ensure it
                stays that way. That's why we created Everything Necessary – to
                be your single, reliable source for all your home service needs
                throughout New York, New Jersey, and Connecticut. From essential
                repairs and routine maintenance to exciting home improvement
                projects, we connect you with carefully vetted professionals
                committed to quality workmanship and your complete peace of
                mind.
              </p>
            </div>
          </div>
        </section>

        {/* Our Story Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-4xl mx-auto scroll-reveal">
              <h2 className="text-3xl font-display font-bold mb-6 text-center">
                Our Story - Solving Homeowner Frustrations
              </h2>
              <p className="text-lg text-muted-foreground mb-6">
                Like many homeowners in the Tri-State area, we've personally
                experienced the challenges of finding dependable, trustworthy,
                and efficient help for our homes. The frustration of endless
                online searches, juggling multiple contractors, worrying about
                quality, and managing countless schedules can be overwhelming.
                We realized there had to be a better way.
              </p>
              <p className="text-lg text-muted-foreground mb-6">
                That's why we built Everything Necessary. We envisioned a
                company that would simplify home maintenance for busy
                homeowners. A company that would be more than just a directory –
                a true partner that takes the guesswork and hassle out of
                finding and managing home services. We set out to create a
                service that homeowners could genuinely rely on for everything
                necessary to keep their homes running smoothly, safely, and
                beautifully, year after year.
              </p>
            </div>
          </div>
        </section>

        {/* Core Values Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-4xl mx-auto scroll-reveal">
              <h2 className="text-3xl font-display font-bold mb-10 text-center">
                Our Commitment to Tri-State Homeowners
              </h2>
              <p className="text-lg text-muted-foreground mb-8 text-center">
                At Everything Necessary, we are guided by a core set of values
                that drive everything we do:
              </p>

              <div className="grid md:grid-cols-2 gap-8 mt-10">
                <div className="bg-blue-50 p-6 rounded-xl">
                  <div className="flex items-center mb-4">
                    <div className="bg-blue-100 p-3 rounded-full text-blue-600 mr-4">
                      <Clock className="w-6 h-6" />
                    </div>
                    <h3 className="text-xl font-semibold">
                      Reliability You Can Count On
                    </h3>
                  </div>
                  <p className="text-muted-foreground">
                    We understand that your time is valuable and that you need
                    services performed promptly and dependably. We partner with
                    thoroughly vetted professionals who share our commitment to
                    punctuality, clear communication, and consistently
                    delivering high-quality results. When you choose Everything
                    Necessary, you can be confident that the job will be done
                    right, on schedule.
                  </p>
                </div>

                <div className="bg-blue-50 p-6 rounded-xl">
                  <div className="flex items-center mb-4">
                    <div className="bg-blue-100 p-3 rounded-full text-blue-600 mr-4">
                      <Star className="w-6 h-6" />
                    </div>
                    <h3 className="text-xl font-semibold">
                      Unparalleled Convenience
                    </h3>
                  </div>
                  <p className="text-muted-foreground">
                    Home maintenance shouldn't be a chore. We make it easy to
                    find and book the services you need, all in one place. Our
                    simple online request process and our broad network of
                    service providers are designed to save you time and effort.
                    From a leaky faucet to a full kitchen remodel, Everything
                    Necessary streamlines the process, so you can get back to
                    enjoying your home.
                  </p>
                </div>

                <div className="bg-blue-50 p-6 rounded-xl">
                  <div className="flex items-center mb-4">
                    <div className="bg-blue-100 p-3 rounded-full text-blue-600 mr-4">
                      <Building className="w-6 h-6" />
                    </div>
                    <h3 className="text-xl font-semibold">
                      Quality & Professionalism, Guaranteed
                    </h3>
                  </div>
                  <p className="text-muted-foreground">
                    We are dedicated to connecting you with skilled,
                    experienced, and insured professionals who are masters in
                    their trades. We carefully vet every service provider in our
                    network to ensure they meet our high standards for quality,
                    expertise, and customer service. We stand behind the quality
                    of the work facilitated through Everything Necessary because
                    your satisfaction is our top priority.
                  </p>
                </div>

                <div className="bg-blue-50 p-6 rounded-xl">
                  <div className="flex items-center mb-4">
                    <div className="bg-blue-100 p-3 rounded-full text-blue-600 mr-4">
                      <MapPin className="w-6 h-6" />
                    </div>
                    <h3 className="text-xl font-semibold">
                      Serving Our Tri-State Community
                    </h3>
                  </div>
                  <p className="text-muted-foreground">
                    We are proud to be a part of the New York, New Jersey, and
                    Connecticut Tri-State community. We are committed to serving
                    our neighbors with integrity, respect, and a dedication to
                    enhancing the homes and lives of those in our region. We
                    understand the unique needs of Tri-State homeowners and are
                    here to provide tailored solutions you can trust.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action Section */}
        <section className="py-16 bg-blue-100">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-3xl mx-auto text-center scroll-reveal">
              <h2 className="text-3xl font-display font-bold mb-6">
                Ready to Experience the Everything Necessary Difference?
              </h2>
              <p className="text-xl text-muted-foreground mb-8">
                Stop spending your valuable time stressing about home
                maintenance. Let Everything Necessary become your trusted
                partner for a happier, healthier home.
              </p>
              <Link
                to="/#contact"
                className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-8 rounded-md shadow-sm transition-colors"
              >
                Contact Us Today
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default AboutUs;
