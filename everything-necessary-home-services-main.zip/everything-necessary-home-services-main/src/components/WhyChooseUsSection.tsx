
import { useEffect, useRef } from 'react';
import { ShieldCheck, UserCheck, Clock, ThumbsUp, Headphones, CreditCard } from 'lucide-react';

const features = [
  {
    icon: <ShieldCheck className="w-6 h-6" />,
    title: "Reliable & Trusted",
    description: "All our professionals are thoroughly vetted, licensed, and insured for your peace of mind."
  },
  {
    icon: <UserCheck className="w-6 h-6" />,
    title: "Vetted Professionals",
    description: "We carefully select experts with proven track records and extensive experience."
  },
  {
    icon: <Clock className="w-6 h-6" />,
    title: "Prompt Service",
    description: "We understand that home issues need quick attention. Our team responds promptly to all requests."
  },
  {
    icon: <ThumbsUp className="w-6 h-6" />,
    title: "Quality Guaranteed",
    description: "We stand behind our work with service guarantees and follow-up support."
  },
  {
    icon: <Headphones className="w-6 h-6" />,
    title: "Customer Support",
    description: "Our friendly team is available to address your questions and concerns at any time."
  },
  {
    icon: <CreditCard className="w-6 h-6" />,
    title: "Transparent Pricing",
    description: "No hidden fees or surprises. We provide clear, upfront pricing for all services."
  }
];

const WhyChooseUsSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1 }
    );

    const scrollElements = document.querySelectorAll('.scroll-reveal');
    scrollElements.forEach(el => observer.observe(el));

    return () => {
      scrollElements.forEach(el => observer.unobserve(el));
    };
  }, []);

  return (
    <section id="why-choose-us" className="py-16 md:py-24 bg-blue-50" ref={sectionRef}>
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16 scroll-reveal">
          <div className="inline-block bg-blue-200 text-blue-800 px-3 py-1 rounded-full text-sm font-medium mb-4">
            Why Choose Us
          </div>
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-6 text-foreground">
            Service You Can Trust
          </h2>
          <p className="text-lg text-muted-foreground">
            Experience peace of mind with our exceptional service standards and commitment to customer satisfaction.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="scroll-reveal bg-white rounded-xl p-6 shadow-sm border border-gray-100"
              style={{ transitionDelay: `${0.1 * index}s` }}
            >
              <div className="text-blue-600 mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUsSection;
