
import { useEffect, useRef } from 'react';
import { Star } from 'lucide-react';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

const testimonials = [
  {
    quote: "Everything Necessary sent a plumber within hours of my emergency call. Professional, courteous, and fixed the issue fast.",
    author: "Robert Wilson",
    location: "New York, NY",
    rating: 5,
    initials: "RW",
    bgColor: "bg-blue-500"
  },
  {
    quote: "I've used their HVAC services twice now. Both times, the technicians were knowledgeable and efficient. My AC has never run better!",
    author: "Jennifer Smith",
    location: "Newark, NJ",
    rating: 5,
    initials: "JS",
    bgColor: "bg-green-500"
  },
  {
    quote: "Had electrical work done throughout my home. The team was punctual, clean, and thorough. Highly recommend their services.",
    author: "Michael Thompson",
    location: "Stamford, CT",
    rating: 5,
    initials: "MT",
    bgColor: "bg-purple-500"
  },
  {
    quote: "The renovation team transformed my kitchen beyond expectations. They kept to the budget and timeline. Couldn't be happier!",
    author: "Sarah Johnson",
    location: "Brooklyn, NY",
    rating: 5,
    initials: "SJ",
    bgColor: "bg-amber-500"
  }
];

const TestimonialsSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1 }
    );

    const scrollElements = document.querySelectorAll('.scroll-reveal');
    scrollElements.forEach(el => observer.observe(el));

    return () => {
      scrollElements.forEach(el => observer.unobserve(el));
    };
  }, []);

  return (
    <section className="py-16 md:py-24 bg-white" ref={sectionRef}>
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16 scroll-reveal">
          <div className="inline-block bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium mb-4">
            Testimonials
          </div>
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-6 text-foreground">
            What Our Customers Say
          </h2>
          <p className="text-lg text-muted-foreground">
            Don't just take our word for it. Here's what homeowners in the Tri-State area have to say about our services.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index} 
              className="scroll-reveal bg-blue-50 border border-blue-100 p-6 rounded-xl relative"
              style={{ transitionDelay: `${0.1 * index}s` }}
            >
              <div className="mb-4 flex">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="text-foreground mb-4 italic">{testimonial.quote}</p>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">{testimonial.author}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                </div>
                <Avatar className={`w-12 h-12 ${testimonial.bgColor} animate-pulse`}>
                  <AvatarFallback className="text-white font-medium">
                    {testimonial.initials}
                  </AvatarFallback>
                </Avatar>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
