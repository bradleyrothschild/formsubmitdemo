
import { MapPin, Phone, Mail, Facebook, Twitter, Instagram, Linkedin, Home } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Home className="w-6 h-6 text-blue-400" strokeWidth={2.5} />
              <h3 className="text-2xl font-display font-bold">Everything Necessary</h3>
            </div>
            <p className="text-xs text-blue-400 tracking-wide mb-3">
              YOUR TRUSTED HOME SERVICES ADVISOR
            </p>
            <p className="text-gray-400 mb-6">
              Your trusted partner for all home service needs in the Tri-State area.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="bg-gray-800 hover:bg-blue-600 transition-colors p-2 rounded-full">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="bg-gray-800 hover:bg-blue-600 transition-colors p-2 rounded-full">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="bg-gray-800 hover:bg-blue-600 transition-colors p-2 rounded-full">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="https://www.linkedin.com/company/everything-necessary-your-trusted-home-services-advisor/about/?viewAsMember=true" className="bg-gray-800 hover:bg-blue-600 transition-colors p-2 rounded-full">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Our Services</h4>
            <ul className="space-y-2">
              <li><Link to="/services" className="text-gray-400 hover:text-white transition-colors">Plumbing</Link></li>
              <li><Link to="/services" className="text-gray-400 hover:text-white transition-colors">HVAC</Link></li>
              <li><Link to="/services" className="text-gray-400 hover:text-white transition-colors">Electrical</Link></li>
              <li><Link to="/services" className="text-gray-400 hover:text-white transition-colors">Home Repair</Link></li>
              <li><Link to="/services" className="text-gray-400 hover:text-white transition-colors">Renovation</Link></li>
              <li><Link to="/services" className="text-gray-400 hover:text-white transition-colors">Home Inspection</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><Link to="/about" className="text-gray-400 hover:text-white transition-colors">About Us</Link></li>
              <li><Link to="/services" className="text-gray-400 hover:text-white transition-colors">All Services</Link></li>
              <li><Link to="/blog" className="text-gray-400 hover:text-white transition-colors">Blog</Link></li>
              <li><a href="/#why-choose-us" className="text-gray-400 hover:text-white transition-colors">Why Choose Us</a></li>
              <li><a href="/#areas" className="text-gray-400 hover:text-white transition-colors">Service Areas</a></li>
              <li><Link to="/#contact" className="text-gray-400 hover:text-white transition-colors">Contact Us</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Information</h4>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                <p className="text-gray-400">203 Baltic Street, Brooklyn, NY 11201</p>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-blue-400 flex-shrink-0" />
                <p className="text-gray-400">(646) 902-1884</p>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-blue-400 flex-shrink-0" />
                <p className="text-gray-400">info@necessaryhome.com</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              &copy; {currentYear} Everything Necessary. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Privacy Policy</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Terms of Service</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Sitemap</a>
            </div>
          </div>
        </div>
      </div>
    </footer>;
};
export default Footer;
