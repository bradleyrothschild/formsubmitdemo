
import { useEffect, useRef, useState } from 'react';
import { MapPin, AlertCircle, Globe } from 'lucide-react';
import 'mapbox-gl/dist/mapbox-gl.css';
import { toast } from "sonner";

const AreasSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const mapContainer = useRef<HTMLDivElement>(null);
  const [mapLoaded, setMapLoaded] = useState(false);
  const [mapError, setMapError] = useState<string | null>(null);

  // Initialize intersection observer for animations
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1 }
    );

    const scrollElements = document.querySelectorAll('.scroll-reveal');
    scrollElements.forEach(el => observer.observe(el));

    return () => {
      scrollElements.forEach(el => observer.unobserve(el));
    };
  }, []);

  // Initialize map
  useEffect(() => {
    // Exit early if container not ready or map already initialized
    if (!mapContainer.current || mapLoaded) return;
    
    const initializeMap = async () => {
      try {
        // Dynamically import mapboxgl to avoid SSR issues
        const mapboxgl = await import('mapbox-gl');
        
        // Use a valid Mapbox token
        mapboxgl.default.accessToken = 'pk.eyJ1IjoibG92YWJsZS1haS1kZW1vIiwiYSI6ImNsdmhmZTA1djAyaHQyanA5Z29uem40dHkifQ.a3lFPHBvIXA3OZ1s1DI0SQ';
        
        if (!mapContainer.current) return;
        
        // Create the map instance
        const mapInstance = new mapboxgl.default.Map({
          container: mapContainer.current,
          style: 'mapbox://styles/mapbox/light-v11',
          center: [-74.0060, 40.7128], // NYC as center point
          zoom: 6,
          interactive: true
        });
        
        // Add navigation controls
        mapInstance.addControl(new mapboxgl.default.NavigationControl(), 'top-right');
        
        // Handle map load success
        mapInstance.on('load', () => {
          setMapLoaded(true);
          
          // Add tri-state highlighted area
          try {
            mapInstance.addSource('tri-state-area', {
              type: 'geojson',
              data: {
                type: 'Feature',
                geometry: {
                  type: 'Polygon',
                  coordinates: [[
                    [-80.519851, 38.928519], // Southwest
                    [-80.519851, 45.013027], // Northwest
                    [-71.856214, 45.013027], // Northeast
                    [-71.856214, 38.928519], // Southeast
                    [-80.519851, 38.928519]  // Close the polygon
                  ]]
                }
              }
            });
            
            mapInstance.addLayer({
              id: 'tri-state-area-fill',
              type: 'fill',
              source: 'tri-state-area',
              layout: {},
              paint: {
                'fill-color': '#3b82f6',
                'fill-opacity': 0.2
              }
            });
            
            mapInstance.addLayer({
              id: 'tri-state-area-border',
              type: 'line',
              source: 'tri-state-area',
              layout: {},
              paint: {
                'line-color': '#1d4ed8',
                'line-width': 2
              }
            });
            
            // Add markers for main service hubs
            const hubs = [
              { name: "New York City", coordinates: [-74.0060, 40.7128] },
              { name: "Albany", coordinates: [-73.7562, 42.6526] },
              { name: "Newark", coordinates: [-74.1724, 40.7357] },
              { name: "Hartford", coordinates: [-72.6823, 41.7658] }
            ];
            
            hubs.forEach(hub => {
              // Create a marker element
              const markerEl = document.createElement('div');
              markerEl.className = 'flex items-center justify-center w-8 h-8 bg-blue-600 rounded-full text-white shadow-lg';
              markerEl.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path><circle cx="12" cy="10" r="3"></circle></svg>';
              
              // Add popup
              const popup = new mapboxgl.default.Popup({ offset: 25 })
                .setHTML(`<p class="font-semibold">${hub.name}</p>`);
                
              // Add marker to map
              new mapboxgl.default.Marker(markerEl)
                .setLngLat(hub.coordinates)
                .setPopup(popup)
                .addTo(mapInstance);
            });
          } catch (error) {
            console.error("Error setting up map layers:", error);
            setMapError('Error setting up map layers.');
          }
        });
        
        // Error handling
        mapInstance.on('error', (e) => {
          console.error('Mapbox error:', e);
          setMapError('Unable to load the map. Please try again later.');
          setMapLoaded(false);
          toast.error('Map failed to load. Showing fallback view.');
        });
        
        // Clean up
        return () => {
          mapInstance.remove();
        };
      } catch (error) {
        console.error("Error initializing map:", error);
        setMapError('Unable to initialize the map component.');
        setMapLoaded(false);
        toast.error('Map initialization failed.');
      }
    };
    
    initializeMap();
  }, [mapLoaded]);

  // Static fallback component when map fails to load
  const FallbackMap = () => (
    <div className="absolute inset-0 bg-blue-50 flex flex-col items-center justify-center p-6 text-center">
      <Globe className="w-16 h-16 text-blue-500 mb-4" />
      <h3 className="text-xl font-semibold mb-3">Tri-State Coverage Area</h3>
      <p className="text-muted-foreground mb-4">
        We proudly serve the entire Tri-State region, including all communities across:
      </p>
      <div className="grid grid-cols-3 gap-6 w-full max-w-md">
        <div className="flex flex-col items-center">
          <MapPin className="w-8 h-8 text-blue-600 mb-2" />
          <span className="font-semibold">New York</span>
        </div>
        <div className="flex flex-col items-center">
          <MapPin className="w-8 h-8 text-blue-600 mb-2" />
          <span className="font-semibold">New Jersey</span>
        </div>
        <div className="flex flex-col items-center">
          <MapPin className="w-8 h-8 text-blue-600 mb-2" />
          <span className="font-semibold">Connecticut</span>
        </div>
      </div>
    </div>
  );

  return (
    <section id="areas" className="py-16 md:py-24 bg-white" ref={sectionRef}>
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="scroll-reveal max-w-xl">
            <div className="inline-block bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium mb-4">
              Areas We Serve
            </div>
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-6 text-foreground">
              Serving the Entire Tri-State Area
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              We provide our comprehensive home services throughout New York, New Jersey, and Connecticut. Our local teams understand the unique needs of homes in each area.
            </p>
            
            <div className="space-y-6">
              <div className="bg-blue-50 rounded-lg p-6 border border-blue-100">
                <h3 className="text-xl font-semibold mb-4 text-foreground">Our Coverage</h3>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-blue-600" />
                    <span className="font-medium">New York</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-blue-600" />
                    <span className="font-medium">New Jersey</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-blue-600" />
                    <span className="font-medium">Connecticut</span>
                  </div>
                </div>
                <p className="mt-4 text-sm text-muted-foreground">
                  Our service areas cover all regions of these three states. Whether you're in a bustling city center or a quiet suburban neighborhood, our teams can reach you.
                </p>
              </div>
            </div>
            
            <div className="mt-8 bg-blue-50 rounded-lg p-4 border border-blue-100">
              <p className="text-blue-800 text-sm font-medium">
                Don't see your specific area on the map? Contact us anyway! We're expanding our service areas regularly.
              </p>
            </div>
          </div>
          
          <div className="scroll-reveal rounded-2xl overflow-hidden shadow-lg relative h-[400px] md:h-[500px]">
            {mapError ? (
              <FallbackMap />
            ) : (
              <>
                <div ref={mapContainer} className="absolute inset-0 w-full h-full" />
                <div className="absolute inset-0 pointer-events-none rounded-2xl border border-blue-100"></div>
                <div className="absolute bottom-4 left-4 bg-white/90 text-foreground px-4 py-2 rounded-full text-sm font-medium inline-flex items-center gap-2 shadow-md">
                  <MapPin className="w-4 h-4 text-blue-600" />
                  Serving NY, NJ & CT
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AreasSection;
