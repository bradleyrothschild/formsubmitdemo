import { useEffect, useRef } from 'react';
import { 
  Wrench, 
  Droplets, 
  Zap, 
  House, 
  Settings, 
  Shield, 
  RefreshCw, 
  Hammer, 
  Sparkles, 
  PaintBucket, 
  Workflow, 
  HeartPulse, 
  ArrowRight
} from 'lucide-react';
import { Link } from 'react-router-dom';

// Custom Icon Components for Service Categories
const PlumbingIcon = ({ className }: { className?: string }) => <Droplets className={className} />;
const ElectricalIcon = ({ className }: { className?: string }) => <Zap className={className} />;
const HVACIcon = ({ className }: { className?: string }) => <Wrench className={className} />;
const HomeRepairIcon = ({ className }: { className?: string }) => <House className={className} />;
const RenovationIcon = ({ className }: { className?: string }) => <Settings className={className} />;
const InspectionIcon = ({ className }: { className?: string }) => <Shield className={className} />;
const CleaningIcon = ({ className }: { className?: string }) => <Sparkles className={className} />;
const ExteriorIcon = ({ className }: { className?: string }) => <PaintBucket className={className} />;
const ImprovementIcon = ({ className }: { className?: string }) => <Hammer className={className} />;
const SpecialtyIcon = ({ className }: { className?: string }) => <Workflow className={className} />;
const EmergencyIcon = ({ className }: { className?: string }) => <HeartPulse className={className} />;
const InstallationIcon = ({ className }: { className?: string }) => <RefreshCw className={className} />;

const serviceData = [
  {
    icon: <PlumbingIcon className="w-6 h-6" />,
    title: "Repairs & Maintenance",
    description: "From plumbing leaks to electrical issues, HVAC repairs and more - we fix problems and keep your home systems running smoothly."
  },
  {
    icon: <InstallationIcon className="w-6 h-6" />,
    title: "Installations & Upgrades",
    description: "New HVAC systems, electrical installations, plumbing fixtures, smart home technology, and more to improve your home's functionality."
  },
  {
    icon: <CleaningIcon className="w-6 h-6" />,
    title: "Home Cleaning",
    description: "Professional cleaning services including house cleaning, carpet cleaning, window washing, and power washing."
  },
  {
    icon: <ExteriorIcon className="w-6 h-6" />,
    title: "Exterior & Property",
    description: "Complete property care with landscaping, tree services, fence repair, deck maintenance, and seasonal services."
  },
  {
    icon: <ImprovementIcon className="w-6 h-6" />,
    title: "Home Improvement",
    description: "Transform your space with kitchen and bathroom remodeling, flooring, painting, and custom carpentry solutions."
  },
  {
    icon: <SpecialtyIcon className="w-6 h-6" />,
    title: "Specialty Services",
    description: "Specialized solutions including junk removal, moving services, mold remediation, and seasonal installations."
  },
  {
    icon: <EmergencyIcon className="w-6 h-6" />,
    title: "Emergency Services",
    description: "24/7 emergency assistance for plumbing, electrical, HVAC failures, water damage, and urgent tree removal."
  }
];

const ServicesSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
          }
        });
      },
      { threshold: 0.1 }
    );

    const scrollElements = document.querySelectorAll('.scroll-reveal');
    scrollElements.forEach(el => observer.observe(el));

    return () => {
      scrollElements.forEach(el => observer.unobserve(el));
    };
  }, []);

  return (
    <section id="services" className="py-16 md:py-24 bg-white" ref={sectionRef}>
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16 scroll-reveal">
          <div className="inline-block bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium mb-4">
            Our Services
          </div>
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-6 text-foreground">
            Everything Your Home Needs
          </h2>
          <p className="text-lg text-muted-foreground">
            We offer a comprehensive range of home services to keep your property running smoothly and efficiently.
          </p>
          <p className="text-lg text-blue-600 font-semibold mt-2">
            Everything necessary for a happy home
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 staggered-fade-in">
          {serviceData.map((service, index) => (
            <div 
              key={index} 
              className="service-card scroll-reveal bg-white border border-gray-100 rounded-xl p-6 shadow-sm hover:shadow-blue transition-all duration-300 hover:border-blue-200"
              style={{ animationDelay: `${0.1 * index}s` }}
            >
              <div className="icon-container mb-5 bg-blue-100 text-blue-600 w-14 h-14 flex items-center justify-center rounded-lg">
                {service.icon}
              </div>
              <h3 className="text-xl font-semibold mb-3">{service.title}</h3>
              <p className="text-muted-foreground">{service.description}</p>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <Link 
            to="/services" 
            className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-800 font-medium text-lg transition-colors"
          >
            View All Services Provided
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
