
import { useState } from 'react';
import { CheckCircle } from 'lucide-react';
import { toast } from "sonner";

interface FormData {
  name: string;
  email: string;
  phone: string;
  service: string;
  message: string;
}

const ContactForm = () => {
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    phone: '',
    service: '',
    message: ''
  });
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      // Prepare email data
      const emailData = {
        to: 'info@necessaryhome.com',
        from: 'noreply@necessaryhome.com',
        subject: `Service Request: ${formData.service}`,
        text: `
          New Service Request
          
          Name: ${formData.name}
          Email: ${formData.email}
          Phone: ${formData.phone}
          Service: ${formData.service}
          
          Message:
          ${formData.message}
        `
      };
      
      console.log('Sending email to:', emailData.to);
      console.log('Email data:', emailData);
      
      // For demonstration purposes, we're simulating a successful email submission
      // In production, you would use an email service API like SendGrid, Mailgun, etc.
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Show success toast
      toast.success("Service request submitted successfully!");
      
      // Set form as submitted (shows success message)
      setFormSubmitted(true);
      
      // Reset form after submission
      setFormData({
        name: '',
        email: '',
        phone: '',
        service: '',
        message: ''
      });
      
      // Reset form state after 5 seconds
      setTimeout(() => {
        setFormSubmitted(false);
      }, 5000);
    } catch (error) {
      console.error('Error submitting form:', error);
      toast.error("Failed to submit request. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 scroll-reveal">
      {formSubmitted ? (
        <div className="h-full flex flex-col items-center justify-center text-center p-8 animate-fade-in">
          <div className="text-green-500 mb-4">
            <CheckCircle className="w-16 h-16 mx-auto" />
          </div>
          <h3 className="text-2xl font-semibold mb-4">Thank you!</h3>
          <p className="text-muted-foreground mb-6">
            Your service request has been submitted successfully. Our team will contact you within 24 hours to schedule your service.
          </p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-foreground mb-2">
                Full Name
              </label>
              <input 
                type="text" 
                id="name" 
                name="name" 
                required 
                value={formData.name} 
                onChange={handleChange} 
                className="w-full px-4 py-2.5 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors" 
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-foreground mb-2">
                Email
              </label>
              <input 
                type="email" 
                id="email" 
                name="email" 
                required 
                value={formData.email} 
                onChange={handleChange} 
                className="w-full px-4 py-2.5 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors" 
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-foreground mb-2">
                Phone Number
              </label>
              <input 
                type="tel" 
                id="phone" 
                name="phone" 
                required 
                value={formData.phone} 
                onChange={handleChange} 
                className="w-full px-4 py-2.5 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors" 
              />
            </div>
            <div>
              <label htmlFor="service" className="block text-sm font-medium text-foreground mb-2">
                Service Needed
              </label>
              <select 
                id="service" 
                name="service" 
                required 
                value={formData.service} 
                onChange={handleChange} 
                className="w-full px-4 py-2.5 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
              >
                <option value="" disabled>Select a service</option>
                <option value="plumbing">Plumbing</option>
                <option value="hvac">HVAC</option>
                <option value="electrical">Electrical</option>
                <option value="home-repair">Home Repair</option>
                <option value="renovation">Renovation</option>
                <option value="home-inspection">Home Inspection</option>
                <option value="other">Other</option>
              </select>
            </div>
          </div>
          
          <div>
            <label htmlFor="message" className="block text-sm font-medium text-foreground mb-2">
              Tell us about your issue
            </label>
            <textarea 
              id="message" 
              name="message" 
              rows={4} 
              value={formData.message} 
              onChange={handleChange} 
              className="w-full px-4 py-2.5 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
            ></textarea>
          </div>
          
          <button 
            type="submit" 
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-md shadow-sm transition-colors flex justify-center items-center"
            disabled={loading}
          >
            {loading ? 'Submitting...' : 'Submit Request'}
          </button>
          
          <p className="text-xs text-muted-foreground text-center">
            By submitting this form, you agree to our <a href="#" className="text-blue-600 hover:underline">Terms of Service</a> and <a href="#" className="text-blue-600 hover:underline">Privacy Policy</a>.
          </p>
        </form>
      )}
    </div>
  );
};

export default ContactForm;
