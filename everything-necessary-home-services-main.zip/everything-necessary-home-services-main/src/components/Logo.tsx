
import { Home } from 'lucide-react';
import { Link } from 'react-router-dom';

interface LogoProps {
  variant?: 'default' | 'mobile';
}

const Logo = ({ variant = 'default' }: LogoProps) => {
  if (variant === 'mobile') {
    return (
      <Link to="/" className="flex items-center gap-2">
        <div className="relative">
          <Home className="w-6 h-6 text-blue-600" strokeWidth={2.5} />
          <div className="absolute inset-0 bg-gradient-to-br from-blue-400/20 to-blue-600/20 blur-sm rounded-full -z-10"></div>
        </div>
        <span className="text-blue-600 font-display font-bold text-xl">EN</span>
      </Link>
    );
  }

  return (
    <Link to="/" className="flex flex-col">
      <div className="flex items-center gap-2">
        <div className="relative">
          <Home className="w-7 h-7 text-blue-600" strokeWidth={2.5} />
          <div className="absolute inset-0 bg-gradient-to-br from-blue-400/20 to-blue-600/20 blur-sm rounded-full -z-10"></div>
        </div>
        <span className="text-blue-600 font-display font-bold text-2xl">EVERYTHING NECESSARY</span>
      </div>
      <span className="text-gray-500 text-xs font-medium tracking-wide ml-9">YOUR TRUSTED HOME SERVICES ADVISOR</span>
    </Link>
  );
};

export default Logo;
