
import { Phone, Mail } from 'lucide-react';

const ContactInfo = () => {
  return (
    <div className="scroll-reveal">
      <div className="inline-block bg-blue-200 text-blue-800 px-3 py-1 rounded-full text-sm font-medium mb-4">
        Get In Touch
      </div>
      <h2 className="text-3xl md:text-4xl font-display font-bold mb-6 text-foreground">
        Request Service Now
      </h2>
      <p className="text-lg text-muted-foreground mb-8">
        Fill out the form and our team will get back to you within 24 hours to schedule your service.
      </p>
      
      <div className="space-y-6">
        <div className="flex items-start gap-4">
          <div className="bg-blue-100 p-3 rounded-full text-blue-600">
            <Phone className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-medium text-foreground">Call Us</h3>
            <p className="text-muted-foreground">(646) 902-1884</p>
            <p className="text-sm text-muted-foreground mt-1">Available 7 days a week, 7am-8pm</p>
          </div>
        </div>
        
        <div className="flex items-start gap-4">
          <div className="bg-blue-100 p-3 rounded-full text-blue-600">
            <Mail className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-medium text-foreground">Email Us</h3>
            <p className="text-muted-foreground">info@necessaryhome.com</p>
            <p className="text-sm text-muted-foreground mt-1">We'll respond within 24 hours</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactInfo;
