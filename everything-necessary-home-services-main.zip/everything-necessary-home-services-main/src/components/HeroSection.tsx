
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const HeroSection = () => {
  return (
    <section className="relative pt-28 pb-20 md:pt-36 md:pb-32 overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-white -z-10 overflow-hidden">
        <div className="absolute -top-32 -right-32 w-96 h-96 bg-blue-100 rounded-full opacity-70"></div>
        <div className="absolute top-1/3 -left-16 w-64 h-64 bg-blue-100 rounded-full opacity-50"></div>
        <div className="absolute -bottom-32 right-1/4 w-80 h-80 bg-blue-100 rounded-full opacity-60"></div>
      </div>
      
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="max-w-2xl animate-fade-in-up">
            <div className="inline-block bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium mb-6">
              Trusted Home Services in the Tri-State Area
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold tracking-tight mb-6 text-foreground">
              Everything Necessary for a <span className="text-blue-600">Happy Home</span>
            </h1>
            <p className="text-lg md:text-xl text-blue-600 font-semibold mb-4 leading-relaxed">
              Home Services Made Simple
            </p>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed">
              Connect with vetted professionals for all your home service needs. From maintenance and repairs to installations and renovations, we've got your home covered.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link 
                to="/#contact" 
                className="inline-flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-medium px-6 py-3 rounded-md shadow-sm transition-all transform hover:translate-y-[-2px]"
              >
                Request Service Now
                <ArrowRight size={18} />
              </Link>
              <a 
                href="#services" 
                className="inline-flex items-center justify-center gap-2 bg-white hover:bg-blue-50 text-blue-600 font-medium px-6 py-3 rounded-md border border-blue-200 shadow-sm transition-colors"
              >
                Explore Our Services
              </a>
            </div>
          </div>
          
          <div className="relative hidden md:block">
            <div className="absolute top-0 left-0 w-full h-full bg-blue-600 rounded-2xl opacity-5 animate-float"></div>
            <div className="absolute top-4 left-4 w-full h-full bg-blue-400 rounded-2xl opacity-5 animate-float" style={{ animationDelay: "0.5s" }}></div>
            <div className="relative z-10 overflow-hidden rounded-2xl shadow-xl animate-fade-in">
              <img 
                src="https://images.unsplash.com/photo-1649972904349-6e44c42644a7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1760&q=80" 
                alt="Happy homeowner" 
                className="w-full h-auto object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/70 to-transparent">
                <p className="text-white font-medium">
                  "Everything Necessary made finding reliable professionals so easy!"
                </p>
                <p className="text-white/90 text-sm mt-1">
                  — Sarah J., Satisfied Customer
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
