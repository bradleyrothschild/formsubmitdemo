
import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { Menu, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import Logo from './Logo';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={cn(
      "fixed top-0 left-0 right-0 z-50 transition-all duration-300 py-4",
      isScrolled ? "bg-white/90 backdrop-blur-md shadow-md" : "bg-transparent"
    )}>
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between">
          {/* Desktop Logo */}
          <div className="hidden md:block">
            <Logo />
          </div>
          
          {/* Mobile Logo */}
          <div className="md:hidden">
            <Logo variant="mobile" />
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/about" className="text-foreground/80 hover:text-blue-600 transition-colors font-medium">
              About Us
            </Link>
            <Link to="/services" className="text-foreground/80 hover:text-blue-600 transition-colors font-medium">
              Services
            </Link>
            <Link to="/blog" className="text-foreground/80 hover:text-blue-600 transition-colors font-medium">
              Blog
            </Link>
            <a href="/#why-choose-us" className="text-foreground/80 hover:text-blue-600 transition-colors font-medium">
              Why Choose Us
            </a>
            <a href="/#areas" className="text-foreground/80 hover:text-blue-600 transition-colors font-medium">
              Areas We Serve
            </a>
            <a href="/#contact" className="bg-blue-600 text-white px-5 py-2.5 rounded-md hover:bg-blue-700 transition-colors shadow-sm font-medium">
              Contact Us
            </a>
          </nav>
          
          {/* Mobile menu button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden text-foreground p-2"
            aria-label="Toggle menu"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>
      
      {/* Mobile Navigation */}
      <div className={cn(
        "md:hidden fixed inset-x-0 top-[65px] z-50 bg-white/95 backdrop-blur-md shadow-lg transition-all duration-300 ease-in-out",
        isOpen ? "max-h-screen opacity-100" : "max-h-0 opacity-0 pointer-events-none"
      )}>
        <nav className="flex flex-col py-6 px-6 space-y-4">
          <Link 
            to="/about" 
            className="text-foreground/80 hover:text-blue-600 py-2 transition-colors font-medium"
            onClick={() => setIsOpen(false)}
          >
            About Us
          </Link>
          <Link 
            to="/services" 
            className="text-foreground/80 hover:text-blue-600 py-2 transition-colors font-medium"
            onClick={() => setIsOpen(false)}
          >
            Services
          </Link>
          <Link 
            to="/blog" 
            className="text-foreground/80 hover:text-blue-600 py-2 transition-colors font-medium"
            onClick={() => setIsOpen(false)}
          >
            Blog
          </Link>
          <a 
            href="/#why-choose-us" 
            className="text-foreground/80 hover:text-blue-600 py-2 transition-colors font-medium"
            onClick={() => setIsOpen(false)}
          >
            Why Choose Us
          </a>
          <a 
            href="/#areas" 
            className="text-foreground/80 hover:text-blue-600 py-2 transition-colors font-medium"
            onClick={() => setIsOpen(false)}
          >
            Areas We Serve
          </a>
          <a 
            href="/#contact" 
            className="bg-blue-600 text-white px-5 py-2.5 rounded-md hover:bg-blue-700 transition-colors shadow-sm font-medium text-center"
            onClick={() => setIsOpen(false)}
          >
            Contact Us
          </a>
        </nav>
      </div>
    </header>
  );
};

export default Navbar;
